package it.univr.dadi;

public class D10 extends Dado{

    protected D10() {
        super(10);
    }
}
