package it.univr.notes.univr.notes;

public class IllegalNoteException extends RuntimeException {
    public IllegalNoteException() {
        super();
    }
}
