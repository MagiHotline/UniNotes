package it.univr.instructions;

public interface Machine {
    int getResult();
}