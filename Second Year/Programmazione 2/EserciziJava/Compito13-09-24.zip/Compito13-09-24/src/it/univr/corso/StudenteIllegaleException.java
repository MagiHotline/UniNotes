package it.univr.corso;

public class StudenteIllegaleException extends RuntimeException {
    public StudenteIllegaleException(String message) {
        super(message);
    }
}
