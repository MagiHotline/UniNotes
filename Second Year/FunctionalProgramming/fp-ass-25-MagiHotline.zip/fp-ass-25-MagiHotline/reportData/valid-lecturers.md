# Valid Lecturers

1 - Cian O'Brien - 16
2 - Oisín Murphy - 18
4 - Fionn McCarthy - 14
5 - Niamh O'Leary - 16
6 - Harley Quinn - 16
7 - Aisling McLaughlin - 14
