# Invalid Lecturers

3 - Tadhg Gallagher - 26
8 - Nkndaskndakndakndakndakndakdnakdnakdnkasdsakndakda - 20
8 - Paolo Imbriani - 100
