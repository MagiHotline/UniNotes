# Valid modules

Functional Programming - hours: 4
Programming Fundamentals 1 - hours: 5
Operating Systems - hours: 5
Physics 2 - hours: 5
Irish Heritage and Folklore - hours: 4
Calculus 2 - hours: 5
Calculus 3 - hours: 5
