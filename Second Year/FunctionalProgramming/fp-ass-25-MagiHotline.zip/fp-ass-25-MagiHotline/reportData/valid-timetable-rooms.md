# Timetable for Room FTG01

[ Tuesday 9:15 ] | Oisín Murphy | Programming Fundamentals 1 | KCOMP_B_4 | FTG01 | 
[ Tuesday 10:15 ] | Oisín Murphy | Programming Fundamentals 1 | KCOMP_B_4 | FTG01 | 
[ Tuesday 11:15 ] | Oisín Murphy | Programming Fundamentals 1 | KCOMP_B_4 | FTG01 | 
[ Tuesday 12:15 ] | Oisín Murphy | Programming Fundamentals 1 | KCOMP_B_4 | FTG01 | 
[ Tuesday 13:15 ] | Oisín Murphy | Programming Fundamentals 1 | KCOMP_B_4 | FTG01 | 

# Timetable for Room FTG02

[ Thursday 9:15 ] | Tadhg Gallagher | Physics 2 | EELEC_C_1 | FTG02 | 
[ Thursday 10:15 ] | Tadhg Gallagher | Physics 2 | EELEC_C_1 | FTG02 | 
[ Thursday 11:15 ] | Tadhg Gallagher | Physics 2 | EELEC_C_1 | FTG02 | 
[ Thursday 12:15 ] | Tadhg Gallagher | Physics 2 | EELEC_C_1 | FTG02 | 
[ Thursday 13:15 ] | Tadhg Gallagher | Physics 2 | EELEC_C_1 | FTG02 | 

# Timetable for Room IT101

[ Monday 9:15 ] | Cian O'Brien | Functional Programming | KCOMP_B_4 | IT101 | 
[ Monday 10:15 ] | Cian O'Brien | Functional Programming | KCOMP_B_4 | IT101 | 
[ Monday 11:15 ] | Cian O'Brien | Functional Programming | KCOMP_B_4 | IT101 | 
[ Monday 12:15 ] | Cian O'Brien | Functional Programming | KCOMP_B_4 | IT101 | 
[ Wednesday 9:15 ] | Fionn McCarthy | Operating Systems | KCOMP_B_4 | IT101 | 
[ Wednesday 10:15 ] | Fionn McCarthy | Operating Systems | KCOMP_B_4 | IT101 | 
[ Wednesday 11:15 ] | Fionn McCarthy | Operating Systems | KCOMP_B_4 | IT101 | 
[ Wednesday 12:15 ] | Fionn McCarthy | Operating Systems | KCOMP_B_4 | IT101 | 
[ Wednesday 13:15 ] | Fionn McCarthy | Operating Systems | KCOMP_B_4 | IT101 | 

