# Valid programmes

1, CS
2, NC
