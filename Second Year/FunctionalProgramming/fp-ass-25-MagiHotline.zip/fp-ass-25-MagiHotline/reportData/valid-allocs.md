# Valid allocations

Cian O'Brien Functional Programming - 4 KCOMP_B_4
Oisín Murphy Programming Fundamentals 1 - 5 KCOMP_B_4
Tadhg Gallagher Physics 2 - 5 EELEC_C_1
Fionn McCarthy Operating Systems - 5 KCOMP_B_4
Niamh O'Leary Calculus 3 - 5 EELEC_C_1
