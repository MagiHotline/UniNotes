# Valid groups

KCOMP_B_4 CS - size: 30
EELEC_C_1 NC - size: 30
KCOFO_B_3 CS - size: 20
KDEVP_B_1 CS - size: 35
