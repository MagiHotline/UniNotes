[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/T99Cuzz7)
[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-2e0aaae1b6195c2367325f4f02e2d04e9abb55f0b24a779b69b11b9e10269abc.svg)](https://classroom.github.com/online_ide?assignment_repo_id=18819779&assignment_repo_type=AssignmentRepo)
# fpProgAss

This is starter code for the Functional Programming Assignment.

# Main learnings of the project

How to effectively use the power of applicatives and functors.
Learnt how to retrieve data from a csv file and then write validations reports on a markdown file.

# Main difficulties that you came across

One of the main difficulties I had was how to apply the validation in an efficient manner.
Plus some validations based on using data structure was a bit tough to handle.
Problems with list manipulation on extracting data and sorting for a certain value.

# Any extra functionalities not mentioned in the spec that you implemented;

I have extended the ValidationResult data type, defining a functor and applicative to make
the validation of a single object easier and more readable.

# Reference to any material outside of notes used.

Mainly: https://hackage.haskell.org
